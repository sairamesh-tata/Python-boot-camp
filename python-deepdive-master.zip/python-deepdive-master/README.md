Python Deep Dive
================

Various Jupyter notebooks and Python sources associated with my Python3: Deep Dive course.

Many of these require Python 3.6 or above.