# module1.py

print(f'loading module1: __name__ = {__name__}')

if __name__ == '__main__':
    print('module1 was run...')