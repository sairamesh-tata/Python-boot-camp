print('executing module1_1b...')

value = 'module1_1b value'