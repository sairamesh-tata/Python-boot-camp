def create_database(database_path: str):
    # TODO: generate the database
    pass


def save_words_to_database(database_path: str, words_list: list):
    # TODO: save the words to the database
    pass
