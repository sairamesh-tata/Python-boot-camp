# -*- coding: utf-8 -*-

städte = u'Basel Genève Zürich'.split()

for stadt in städte:
    print(stadt)
