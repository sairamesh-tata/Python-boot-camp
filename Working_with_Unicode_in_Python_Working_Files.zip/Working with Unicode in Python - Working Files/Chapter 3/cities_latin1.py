# -*- coding: latin1 -*-

cities = u'Basel Gen�ve Z�rich'.split()

for city in cities:
    print(city)
