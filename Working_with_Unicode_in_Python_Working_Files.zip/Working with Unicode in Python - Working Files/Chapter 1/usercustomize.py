import win_unicode_console
win_unicode_console.enable()
